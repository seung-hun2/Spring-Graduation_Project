package com.shop.STYLE.GUIDE.domain;

import lombok.Builder;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

@Entity
public class Clothes {
    @Id
    private Long idx;
    private String pic_name;
    private String pic_storename;
    private String pic_content;
    @Enumerated(EnumType.STRING)
    private ClothesType clothestype;

    public Clothes() {
    }

    @Builder
    public Clothes(Long idx, String pic_name, String pic_storePath, ClothesType clothestype){
        this.idx = idx;
        this.pic_name = pic_name;
        this.pic_storename = pic_storePath;
        this.clothestype = clothestype;
    }

    public Long getIdx() {
        return idx;
    }

    public void setIdx(Long idx) {
        this.idx = idx;
    }

    public String getPic_name() {
        return pic_name;
    }

    public void setPic_name(String pic_name) {
        this.pic_name = pic_name;
    }

    public String getPic_storename() {
        return pic_storename;
    }

    public void setPic_storename(String pic_storename) {
        this.pic_storename = pic_storename;
    }

    public String getPic_content() {
        return pic_content;
    }

    public void setPic_content(String pic_content) {
        this.pic_content = pic_content;
    }



}
