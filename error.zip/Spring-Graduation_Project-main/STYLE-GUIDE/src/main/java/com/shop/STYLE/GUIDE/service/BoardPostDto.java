package com.shop.STYLE.GUIDE.service;

import com.shop.STYLE.GUIDE.domain.ClothesType;
import com.shop.STYLE.GUIDE.domain.tb_user_info;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Data
@NoArgsConstructor
public class BoardPostDto {
    private tb_user_info writer;
    private String title;
    private String content;
    private Map<ClothesType, List<MultipartFile>> attachmentFiles = new ConcurrentHashMap<>();

    @Builder
    public BoardPostDto(tb_user_info writer, String title, String content, Map<ClothesType, List<MultipartFile>> attachmentFiles) {
        this.writer = writer;
        this.title = title;
        this.content = content;
        this.attachmentFiles = attachmentFiles;
    }

//    public Board createBoard() {
//        return Board.builder()
//                .writer(writer)
//                .title(title)
//                .writeTime(LocalDateTime.now())
//                .content(content)
//                .attachedFiles(new ArrayList<>())
//                .isDeleted(false)
//                .hit(0)
//                .build();
//    }
}
