package com.shop.STYLE.GUIDE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StyleGuideApplication {

	public static void main(String[] args) {
		SpringApplication.run(StyleGuideApplication.class, args);
	}

}
