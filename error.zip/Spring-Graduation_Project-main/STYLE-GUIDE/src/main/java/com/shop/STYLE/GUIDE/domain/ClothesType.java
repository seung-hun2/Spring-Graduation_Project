package com.shop.STYLE.GUIDE.domain;

public enum ClothesType {
    IMAGE, GENERAL
}
