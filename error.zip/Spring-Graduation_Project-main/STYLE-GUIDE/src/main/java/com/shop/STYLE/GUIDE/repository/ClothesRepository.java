package com.shop.STYLE.GUIDE.repository;

import com.shop.STYLE.GUIDE.domain.Clothes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClothesRepository extends JpaRepository<Clothes, Long> {
}
