package com.shop.STYLE.GUIDE.service;

import com.shop.STYLE.GUIDE.domain.ClothesType;
import com.shop.STYLE.GUIDE.domain.tb_user_info;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Data
@NoArgsConstructor
public class BoardAddForm {
    private String title;
    private String content;
    private List<MultipartFile> imageFiles;
    private List<MultipartFile> generalFiles;

    @Builder
    public BoardAddForm(String title, String content, List<MultipartFile> imageFiles, List<MultipartFile> generalFiles) {
        this.title = title;
        this.content = content;
        this.imageFiles = (imageFiles != null) ? imageFiles : new ArrayList<>();
        this.generalFiles = (generalFiles != null) ? generalFiles : new ArrayList<>();
    }


    public BoardPostDto createBoardPostDto(tb_user_info user_info) {
        Map<ClothesType, List<MultipartFile>> attachments = getAttachmentTypeListMap();
        return BoardPostDto.builder()
                .title(title)
                .writer(user_info)
                .content(content)
                .attachmentFiles(attachments)
                .build();
    }

    private Map<ClothesType, List<MultipartFile>> getAttachmentTypeListMap() {
        Map<ClothesType, List<MultipartFile>> clothes = new ConcurrentHashMap<>();
        clothes.put(ClothesType.IMAGE, imageFiles);
        clothes.put(ClothesType.GENERAL, generalFiles);
        return clothes;
    }
}
