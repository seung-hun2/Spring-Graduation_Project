package com.shop.STYLE.GUIDE.service;

public class Board {
}
