package com.shop.STYLE.GUIDE.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;


@Controller
@Slf4j
public class AdminController {
    @GetMapping("/admin")
    public String admin() {
        return "adminpage/Admin";
    }

    @GetMapping("/member")
    public String member() {
        return "adminpage/Member";
    }
    @GetMapping("/sales")
    public String sales() {
        return "adminpage/Sales";
    }

    @GetMapping("/upload")
    public String upload() {
        return "adminpage/Upload";
    }

    @PostMapping(value = "/uploadaction")
    public void uploadForm(MultipartFile[] uploadfile, Model model){
//        String uploadFolder = "C:\\storage";
//        for(MultipartFile multipartFile : uploadfile){
//            log.info("---------");
//            log.info("file name"+multipartFile.getOriginalFilename());
//            log.info("file size"+multipartFile.getSize());
//
//            File savefile = new File(uploadFolder, multipartFile.getOriginalFilename());
//            try{
//                multipartFile.transferTo(savefile);
//            }catch (Exception e){
//                e.printStackTrace();
//            }
//        }
//        return "adminpage/Upload";

    }



}
