package com.shop.STYLE.GUIDE.filestore;

import com.shop.STYLE.GUIDE.domain.Clothes;
import com.shop.STYLE.GUIDE.domain.ClothesType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Component
public class FileStore {
    //@Value("${file.dir}/")
    private String fileDirPath;

    public List<Clothes> storeFiles(List<MultipartFile> multipartFiles, ClothesType clothestype) throws IOException {
        List<Clothes> attachments = new ArrayList<>();
        for (MultipartFile multipartFile : multipartFiles) {
            if (!multipartFile.isEmpty()) {
                attachments.add(storeFile(multipartFile, clothestype));
            }
        }

        return attachments;
    }

    public Clothes storeFile(MultipartFile multipartFile, ClothesType clothestype) throws IOException {
        if (multipartFile.isEmpty()) {
            return null;
        }

        String originalFilename = multipartFile.getOriginalFilename();
        String storeFilename = createStoreFilename(originalFilename);
        multipartFile.transferTo(new File(createPath(storeFilename, clothestype)));

        return Clothes.builder()
                .pic_name(originalFilename)
                .pic_storePath(storeFilename)
                .clothestype(clothestype)
                .build();

    }

    public String createPath(String storeFilename, ClothesType clothestype) {
        String viaPath = (clothestype == ClothesType.IMAGE) ? "images/" : "generals/";
        return fileDirPath+viaPath+storeFilename;
    }

    private String createStoreFilename(String originalFilename) {
        String uuid = UUID.randomUUID().toString();
        String ext = extractExt(originalFilename);
        String storeFilename = uuid + ext;

        return storeFilename;
    }

    private String extractExt(String originalFilename) {
        int idx = originalFilename.lastIndexOf(".");
        String ext = originalFilename.substring(idx);
        return ext;
    }
}
